# Get image list
python3 scrape_imgs.py --input 2015.csv --output raw_img

# Create canny edge dataset
python3 canny_edges.py --input raw_img --output train_img

# Create PhotoSketch sketches
sh ./PhotoSketch/scripts/test_pretrained.sh

# Create PhotoSketch dataset
python3 make_sketch_dataset.py --img raw_img --sketch sketches --output train_img

# Train network
python3 train_network.py --filters 16
