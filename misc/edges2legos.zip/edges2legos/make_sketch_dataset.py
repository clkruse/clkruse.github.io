import cv2
import numpy as np
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--img', default='raw_img',
                    help="raw images to combine")
parser.add_argument('--sketch', default='sketches',
                    help="processed images to combine ")
parser.add_argument('--output', default='train_img',
                    help="directory to output combined images")

args = parser.parse_args()

img_dir = args.img
sketch_dir = args.sketch
output = args.output

for img_name in os.listdir(img_dir):
    if img_name != '.DS_Store':
        #print(img_name)
        img = cv2.imread(img_dir + '/' + img_name)
        sketch = cv2.imread(sketch_dir + '/' + img_name[:-4] + '.png')

        dim = img.shape[0:2]
        top = int((max(dim) - dim[0]) / 2)
        bottom = int((max(dim) - dim[0]) / 2)
        left = int((max(dim) - dim[1]) / 2)
        right = int((max(dim) - dim[1]) / 2)
        sq_img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=[255,255,255])

        sq_img = cv2.resize(sq_img, (286,286))

        sq_sketch =  cv2.copyMakeBorder(sketch, top, bottom, left, right, cv2.BORDER_CONSTANT, value=[255,255,255])
        sq_sketch = cv2.resize(sq_sketch, (286,286))

        both = np.hstack((sq_img, sq_sketch))
        cv2.imwrite(output + '/sketch_' + img_name, both)
