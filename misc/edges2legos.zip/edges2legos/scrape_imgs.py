import urllib.request
import pandas as pd
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--input', default='all.csv',
                    help="input file name defining image URLs to scrape")
parser.add_argument('--output', default='raw_img',
                    help="directory to output raw images")

args = parser.parse_args()

db = pd.read_csv(args.input)

if not os.path.exists(args.output):
    os.makedirs(args.output)

for img, name in zip(db['ImageURL'], db['SetID']):
    try:
        urllib.request.urlretrieve(
            img, args.output + '/' + str(name) + '.jpg')
    except:
        pass
