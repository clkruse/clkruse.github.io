import cv2
import numpy as np
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--input', default='all.csv',
                    help="input file name defining image URLs to scrape")
parser.add_argument('--output', default='raw_img',
                    help="directory to output raw images")

args = parser.parse_args()

input = args.input
output = args.output

if not os.path.exists(output):
    os.makedirs(output)

for img_name in os.listdir(input):
    if img_name != '.DS_Store':
        img = cv2.imread(input + '/' + img_name)


        dim = img.shape[0:2]
        top = int((max(dim) - dim[0]) / 2)
        bottom = int((max(dim) - dim[0]) / 2)
        left = int((max(dim) - dim[1]) / 2)
        right = int((max(dim) - dim[1]) / 2)
        sq_img = cv2.copyMakeBorder(
            img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=[255, 255, 255])

        sq_img = cv2.resize(sq_img, (286, 286))

        blur_img = cv2.GaussianBlur(sq_img,(9,9),0)
        edges = cv2.Canny(blur_img, 5, 250)
        edges = np.invert(edges)
        edges = np.moveaxis([edges, edges, edges], 0, 2)

        both = np.hstack((sq_img, edges))
        cv2.imwrite(output + '/canny_' + img_name, both)
